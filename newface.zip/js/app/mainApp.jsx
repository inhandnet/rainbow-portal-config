<% web_exec('show interface') %>
<% web_exec('show running-config route') %>