<% web_exec('show running-config route') %>
<% web_exec('show running-config cellular') %>
<% web_exec('show running-config dialer') %>
<% web_exec('show running-config route') %>
<% web_exec('show interface vlan') %>
<% web_exec('show running-config name-server') %>