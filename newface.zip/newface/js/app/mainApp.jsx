<% web_exec('show interface') %>
<% web_exec('show running-config route') %>
<% ih_user_info(); %>
<% ih_sysinfo(); %>