<% web_exec('show running-config portal') %>
